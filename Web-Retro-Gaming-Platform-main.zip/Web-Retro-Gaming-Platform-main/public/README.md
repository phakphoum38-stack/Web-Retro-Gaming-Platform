Public assets folder
